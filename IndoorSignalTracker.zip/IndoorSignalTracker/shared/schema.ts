import { pgTable, text, serial, integer, boolean, timestamp, real } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const devices = pgTable("devices", {
  id: serial("id").primaryKey(),
  ssid: text("ssid").notNull(),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

export const rssiRecords = pgTable("rssi_records", {
  id: serial("id").primaryKey(),
  sessionId: text("session_id").notNull(),
  serialNumber: integer("serial_number").notNull(),
  timestamp: timestamp("timestamp").notNull(),
  deviceId: integer("device_id").references(() => devices.id),
  rssiValue: real("rssi_value").notNull(),
});

export const recordingSessions = pgTable("recording_sessions", {
  id: serial("id").primaryKey(),
  sessionId: text("session_id").notNull().unique(),
  deviceCount: integer("device_count").notNull(),
  startTime: timestamp("start_time").notNull(),
  endTime: timestamp("end_time"),
  isActive: boolean("is_active").default(true),
});

export const insertDeviceSchema = createInsertSchema(devices).pick({
  ssid: true,
  isActive: true,
});

export const insertRssiRecordSchema = createInsertSchema(rssiRecords).pick({
  sessionId: true,
  serialNumber: true,
  timestamp: true,
  deviceId: true,
  rssiValue: true,
});

export const insertRecordingSessionSchema = createInsertSchema(recordingSessions).pick({
  sessionId: true,
  deviceCount: true,
  startTime: true,
  endTime: true,
  isActive: true,
});

export type Device = typeof devices.$inferSelect;
export type InsertDevice = z.infer<typeof insertDeviceSchema>;

export type RssiRecord = typeof rssiRecords.$inferSelect;
export type InsertRssiRecord = z.infer<typeof insertRssiRecordSchema>;

export type RecordingSession = typeof recordingSessions.$inferSelect;
export type InsertRecordingSession = z.infer<typeof insertRecordingSessionSchema>;

export interface RssiDataPoint {
  serialNumber: number;
  timestamp: string;
  rssiValues: Record<string, number>;
}

export interface SessionConfig {
  deviceCount: number;
  selectedSSIDs: string[];
}
