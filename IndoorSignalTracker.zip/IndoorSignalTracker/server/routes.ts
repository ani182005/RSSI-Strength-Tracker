import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { storage } from "./storage";
import { insertDeviceSchema, insertRecordingSessionSchema, insertRssiRecordSchema, type Device } from "@shared/schema";
import { nanoid } from "nanoid";

// Mock WiFi scanning function - in production, this would interface with actual WiFi hardware
function scanWiFiNetworks(): Promise<Array<{ ssid: string; rssi: number }>> {
  return new Promise((resolve) => {
    // Simulate scanning delay
    setTimeout(() => {
      const mockNetworks = [
        'WiFi_Network_001', 'WiFi_Network_002', 'WiFi_Network_003',
        'WiFi_Network_004', 'WiFi_Network_005', 'WiFi_Network_006',
        'WiFi_Network_007', 'WiFi_Network_008', 'WiFi_Network_009',
        'WiFi_Network_010', 'WiFi_Network_011', 'WiFi_Network_012'
      ].map(ssid => ({
        ssid,
        rssi: Math.floor(Math.random() * 60) - 90 // -90 to -30 dBm
      }));
      resolve(mockNetworks);
    }, 500);
  });
}

// Function to get real-time RSSI for specific SSIDs
async function getRSSIForSSIDs(ssids: string[]): Promise<Record<string, number>> {
  const result: Record<string, number> = {};
  
  // For each manually entered SSID, generate realistic RSSI values
  ssids.forEach(ssid => {
    // Generate realistic RSSI values between -90 dBm (very weak) and -30 dBm (very strong)
    const baseRssi = Math.floor(Math.random() * 60) - 90; // -90 to -30 dBm
    // Add small random variation to simulate real-world fluctuations
    const variation = (Math.random() - 0.5) * 6; // ±3 dBm variation
    result[ssid] = Math.round(baseRssi + variation);
  });
  
  return result;
}

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);

  // WebSocket server for real-time communication
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });
  
  let activeClients = new Set<WebSocket>();
  let recordingInterval: NodeJS.Timeout | null = null;
  let currentSessionId: string | null = null;
  let serialCounter = 0;

  wss.on('connection', (ws) => {
    activeClients.add(ws);
    console.log('WebSocket client connected');

    ws.on('close', () => {
      activeClients.delete(ws);
      console.log('WebSocket client disconnected');
    });

    ws.on('error', (error) => {
      console.error('WebSocket error:', error);
      activeClients.delete(ws);
    });
  });

  // Broadcast to all connected clients
  function broadcast(data: any) {
    const message = JSON.stringify(data);
    activeClients.forEach(client => {
      if (client.readyState === WebSocket.OPEN) {
        client.send(message);
      }
    });
  }

  // Get available WiFi networks (kept for compatibility but not used in manual input mode)
  app.get('/api/wifi/scan', async (req, res) => {
    try {
      const networks = await scanWiFiNetworks();
      res.json(networks);
    } catch (error) {
      console.error('WiFi scan error:', error);
      res.status(500).json({ message: 'Failed to scan WiFi networks' });
    }
  });

  // Configure devices
  app.post('/api/devices/configure', async (req, res) => {
    try {
      const { ssids } = req.body;
      
      if (!Array.isArray(ssids) || ssids.length === 0 || ssids.length > 10) {
        return res.status(400).json({ message: 'Invalid SSID configuration' });
      }

      // Clear existing devices
      await storage.deleteAllDevices();

      // Create new devices
      const devices = [];
      for (const ssid of ssids) {
        const device = await storage.createDevice({ ssid, isActive: true });
        devices.push(device);
      }

      res.json({ devices, message: 'Devices configured successfully' });
    } catch (error) {
      console.error('Device configuration error:', error);
      res.status(500).json({ message: 'Failed to configure devices' });
    }
  });

  // Start recording session
  app.post('/api/recording/start', async (req, res) => {
    try {
      const { deviceCount, ssids } = req.body;

      if (recordingInterval) {
        return res.status(400).json({ message: 'Recording already in progress' });
      }

      // Create new session
      const sessionId = nanoid();
      currentSessionId = sessionId;
      serialCounter = 0;

      await storage.createSession({
        sessionId,
        deviceCount,
        startTime: new Date(),
        isActive: true
      });

      // Get devices for the SSIDs
      const devices = [];
      for (const ssid of ssids) {
        const device = await storage.getDeviceBySSID(ssid);
        if (device) {
          devices.push(device);
        }
      }

      // Start recording interval
      recordingInterval = setInterval(async () => {
        try {
          serialCounter++;
          const timestamp = new Date();
          const rssiValues = await getRSSIForSSIDs(ssids);

          // Store individual RSSI records
          for (const device of devices) {
            const rssiValue = rssiValues[device.ssid];
            if (rssiValue !== undefined) {
              await storage.createRssiRecord({
                sessionId,
                serialNumber: serialCounter,
                timestamp,
                deviceId: device.id,
                rssiValue
              });
            }
          }

          // Broadcast real-time data
          broadcast({
            type: 'rssi_data',
            data: {
              serialNumber: serialCounter,
              timestamp: timestamp.toISOString(),
              rssiValues
            }
          });

        } catch (error) {
          console.error('Recording interval error:', error);
        }
      }, 1000);

      res.json({ sessionId, message: 'Recording started' });
    } catch (error) {
      console.error('Start recording error:', error);
      res.status(500).json({ message: 'Failed to start recording' });
    }
  });

  // Stop recording session
  app.post('/api/recording/stop', async (req, res) => {
    try {
      if (!recordingInterval || !currentSessionId) {
        return res.status(400).json({ message: 'No active recording session' });
      }

      clearInterval(recordingInterval);
      recordingInterval = null;

      await storage.endSession(currentSessionId);

      const sessionId = currentSessionId;
      currentSessionId = null;
      serialCounter = 0;

      broadcast({
        type: 'recording_stopped',
        data: { sessionId }
      });

      res.json({ sessionId, message: 'Recording stopped' });
    } catch (error) {
      console.error('Stop recording error:', error);
      res.status(500).json({ message: 'Failed to stop recording' });
    }
  });

  // Get session data for CSV export
  app.get('/api/recording/export/:sessionId', async (req, res) => {
    try {
      const { sessionId } = req.params;
      
      const session = await storage.getSession(sessionId);
      if (!session) {
        return res.status(404).json({ message: 'Session not found' });
      }

      const records = await storage.getRecordsWithDeviceInfo(sessionId);
      
      // Group records by serial number
      const groupedRecords = new Map();
      records.forEach(record => {
        if (!groupedRecords.has(record.serialNumber)) {
          groupedRecords.set(record.serialNumber, {
            serialNumber: record.serialNumber,
            timestamp: record.timestamp,
            rssiValues: {}
          });
        }
        groupedRecords.get(record.serialNumber).rssiValues[record.device.ssid] = record.rssiValue;
      });

      const exportData = Array.from(groupedRecords.values()).sort((a, b) => a.serialNumber - b.serialNumber);

      res.json({ session, data: exportData });
    } catch (error) {
      console.error('Export data error:', error);
      res.status(500).json({ message: 'Failed to export data' });
    }
  });

  // Reset application state
  app.post('/api/reset', async (req, res) => {
    try {
      // Stop any active recording
      if (recordingInterval) {
        clearInterval(recordingInterval);
        recordingInterval = null;
      }

      if (currentSessionId) {
        await storage.endSession(currentSessionId);
        currentSessionId = null;
      }

      // Clear all data
      await storage.deleteAllDevices();
      serialCounter = 0;

      broadcast({
        type: 'app_reset',
        data: {}
      });

      res.json({ message: 'Application reset successfully' });
    } catch (error) {
      console.error('Reset error:', error);
      res.status(500).json({ message: 'Failed to reset application' });
    }
  });

  return httpServer;
}
