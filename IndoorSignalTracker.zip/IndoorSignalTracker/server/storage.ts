import { devices, rssiRecords, recordingSessions, type Device, type InsertDevice, type RssiRecord, type InsertRssiRecord, type RecordingSession, type InsertRecordingSession, type RssiDataPoint, type SessionConfig } from "@shared/schema";

export interface IStorage {
  // Device management
  createDevice(device: InsertDevice): Promise<Device>;
  getDeviceBySSID(ssid: string): Promise<Device | undefined>;
  getAllDevices(): Promise<Device[]>;
  deleteAllDevices(): Promise<void>;

  // Recording session management
  createSession(session: InsertRecordingSession): Promise<RecordingSession>;
  getActiveSession(): Promise<RecordingSession | undefined>;
  endSession(sessionId: string): Promise<void>;
  getSession(sessionId: string): Promise<RecordingSession | undefined>;

  // RSSI record management
  createRssiRecord(record: InsertRssiRecord): Promise<RssiRecord>;
  getSessionRecords(sessionId: string): Promise<RssiRecord[]>;
  getRecordsWithDeviceInfo(sessionId: string): Promise<Array<RssiRecord & { device: Device }>>;
}

export class MemStorage implements IStorage {
  private devices: Map<number, Device>;
  private rssiRecords: Map<number, RssiRecord>;
  private recordingSessions: Map<number, RecordingSession>;
  private deviceIdCounter: number;
  private recordIdCounter: number;
  private sessionIdCounter: number;

  constructor() {
    this.devices = new Map();
    this.rssiRecords = new Map();
    this.recordingSessions = new Map();
    this.deviceIdCounter = 1;
    this.recordIdCounter = 1;
    this.sessionIdCounter = 1;
  }

  async createDevice(insertDevice: InsertDevice): Promise<Device> {
    const id = this.deviceIdCounter++;
    const device: Device = {
      id,
      ssid: insertDevice.ssid,
      isActive: insertDevice.isActive ?? true,
      createdAt: new Date(),
    };
    this.devices.set(id, device);
    return device;
  }

  async getDeviceBySSID(ssid: string): Promise<Device | undefined> {
    return Array.from(this.devices.values()).find(device => device.ssid === ssid);
  }

  async getAllDevices(): Promise<Device[]> {
    return Array.from(this.devices.values());
  }

  async deleteAllDevices(): Promise<void> {
    this.devices.clear();
    this.deviceIdCounter = 1;
  }

  async createSession(insertSession: InsertRecordingSession): Promise<RecordingSession> {
    const id = this.sessionIdCounter++;
    const session: RecordingSession = {
      id,
      sessionId: insertSession.sessionId,
      deviceCount: insertSession.deviceCount,
      startTime: insertSession.startTime,
      endTime: insertSession.endTime ?? null,
      isActive: insertSession.isActive ?? true,
    };
    this.recordingSessions.set(id, session);
    return session;
  }

  async getActiveSession(): Promise<RecordingSession | undefined> {
    return Array.from(this.recordingSessions.values()).find(session => session.isActive);
  }

  async endSession(sessionId: string): Promise<void> {
    const session = Array.from(this.recordingSessions.values()).find(s => s.sessionId === sessionId);
    if (session) {
      session.isActive = false;
      session.endTime = new Date();
      this.recordingSessions.set(session.id, session);
    }
  }

  async getSession(sessionId: string): Promise<RecordingSession | undefined> {
    return Array.from(this.recordingSessions.values()).find(s => s.sessionId === sessionId);
  }

  async createRssiRecord(insertRecord: InsertRssiRecord): Promise<RssiRecord> {
    const id = this.recordIdCounter++;
    const record: RssiRecord = {
      id,
      sessionId: insertRecord.sessionId,
      serialNumber: insertRecord.serialNumber,
      timestamp: insertRecord.timestamp,
      deviceId: insertRecord.deviceId ?? null,
      rssiValue: insertRecord.rssiValue,
    };
    this.rssiRecords.set(id, record);
    return record;
  }

  async getSessionRecords(sessionId: string): Promise<RssiRecord[]> {
    return Array.from(this.rssiRecords.values()).filter(record => record.sessionId === sessionId);
  }

  async getRecordsWithDeviceInfo(sessionId: string): Promise<Array<RssiRecord & { device: Device }>> {
    const records = await this.getSessionRecords(sessionId);
    return records.map(record => {
      const device = this.devices.get(record.deviceId!);
      return { ...record, device: device! };
    }).filter(record => record.device);
  }
}

export const storage = new MemStorage();
