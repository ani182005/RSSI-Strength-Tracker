import { useState, useEffect } from 'react';
import { DeviceConfiguration } from '@/components/device-configuration';
import { RecordingControls } from '@/components/recording-controls';
import { DataVisualization } from '@/components/data-visualization';
import { SSIDModal } from '@/components/ssid-modal';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useWebSocket } from '@/hooks/use-websocket';
import { apiRequest } from '@/lib/queryClient';
import { generateCSVContent, downloadCSV, generateFilename } from '@/lib/csv-utils';
import { RssiDataPoint } from '@shared/schema';
import { useToast } from '@/hooks/use-toast';
import { Wifi, Smartphone, Database, Clock } from 'lucide-react';

export default function IndoorPositioning() {
  const [deviceCount, setDeviceCount] = useState(0);
  const [selectedSSIDs, setSelectedSSIDs] = useState<string[]>([]);
  const [isRecording, setIsRecording] = useState(false);
  const [recordingData, setRecordingData] = useState<RssiDataPoint[]>([]);
  const [recordingStartTime, setRecordingStartTime] = useState<Date | null>(null);
  const [recordingTime, setRecordingTime] = useState('00:00:00');
  const [currentSessionId, setCurrentSessionId] = useState<string | null>(null);
  const [isSSIDModalOpen, setIsSSIDModalOpen] = useState(false);
  const [isConnected, setIsConnected] = useState(false);

  const { toast } = useToast();

  const { isConnected: wsConnected, error: wsError } = useWebSocket({
    onConnect: () => {
      setIsConnected(true);
      toast({
        title: "Connected",
        description: "WebSocket connection established",
      });
    },
    onDisconnect: () => {
      setIsConnected(false);
      toast({
        title: "Disconnected", 
        description: "Lost connection to server",
        variant: "destructive",
      });
    },
    onMessage: (message) => {
      switch (message.type) {
        case 'rssi_data':
          setRecordingData(prev => [...prev, message.data]);
          break;
        case 'recording_stopped':
          setIsRecording(false);
          break;
        case 'app_reset':
          handleAppReset();
          break;
      }
    },
    onError: () => {
      toast({
        title: "Connection Error",
        description: "Failed to connect to WebSocket server",
        variant: "destructive",
      });
    }
  });

  // Update recording time display
  useEffect(() => {
    let interval: NodeJS.Timeout;
    
    if (isRecording && recordingStartTime) {
      interval = setInterval(() => {
        const elapsed = Date.now() - recordingStartTime.getTime();
        const seconds = Math.floor(elapsed / 1000);
        const minutes = Math.floor(seconds / 60);
        const hours = Math.floor(minutes / 60);
        
        const timeString = `${hours.toString().padStart(2, '0')}:${(minutes % 60).toString().padStart(2, '0')}:${(seconds % 60).toString().padStart(2, '0')}`;
        setRecordingTime(timeString);
      }, 1000);
    }

    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isRecording, recordingStartTime]);

  const handleDeviceCountChange = (count: number) => {
    if (!isRecording) {
      setDeviceCount(count);
      if (count === 0) {
        setSelectedSSIDs([]);
      } else if (selectedSSIDs.length !== count) {
        setSelectedSSIDs([]);
      }
    }
  };

  const handleConfigureSSIDs = () => {
    if (deviceCount > 0 && !isRecording) {
      setIsSSIDModalOpen(true);
    }
  };

  const handleSSIDConfirm = async (ssids: string[]) => {
    try {
      await apiRequest('POST', '/api/devices/configure', { ssids });
      setSelectedSSIDs(ssids);
      setIsSSIDModalOpen(false);
      toast({
        title: "Success",
        description: `Configured ${ssids.length} devices successfully`,
      });
    } catch (error) {
      toast({
        title: "Configuration Error",
        description: "Failed to configure devices",
        variant: "destructive",
      });
    }
  };

  const handleStartRecording = async () => {
    try {
      const response = await apiRequest('POST', '/api/recording/start', {
        deviceCount,
        ssids: selectedSSIDs
      });
      
      const data = await response.json();
      setCurrentSessionId(data.sessionId);
      setIsRecording(true);
      setRecordingStartTime(new Date());
      setRecordingData([]);
      setRecordingTime('00:00:00');
      
      toast({
        title: "Recording Started",
        description: "RSSI data collection has begun",
      });
    } catch (error) {
      toast({
        title: "Recording Error",
        description: "Failed to start recording",
        variant: "destructive",
      });
    }
  };

  const handleStopRecording = async () => {
    try {
      await apiRequest('POST', '/api/recording/stop');
      setIsRecording(false);
      
      toast({
        title: "Recording Stopped",
        description: `Recorded ${recordingData.length} data points`,
      });
    } catch (error) {
      toast({
        title: "Stop Error",
        description: "Failed to stop recording",
        variant: "destructive",
      });
    }
  };

  const handleDownloadCSV = async () => {
    if (!currentSessionId) {
      toast({
        title: "Download Error",
        description: "No session data available",
        variant: "destructive",
      });
      return;
    }

    try {
      const response = await apiRequest('GET', `/api/recording/export/${currentSessionId}`);
      const exportData = await response.json();
      
      const csvContent = generateCSVContent(exportData);
      const filename = generateFilename(currentSessionId);
      
      downloadCSV(csvContent, filename);
      
      toast({
        title: "Download Complete",
        description: `CSV file saved as ${filename}`,
      });
    } catch (error) {
      toast({
        title: "Download Error",
        description: "Failed to download CSV file",
        variant: "destructive",
      });
    }
  };

  const handleRefresh = async () => {
    try {
      await apiRequest('POST', '/api/reset');
      handleAppReset();
      
      toast({
        title: "Application Reset",
        description: "All data has been cleared",
      });
    } catch (error) {
      toast({
        title: "Reset Error",
        description: "Failed to reset application",
        variant: "destructive",
      });
    }
  };

  const handleAppReset = () => {
    setDeviceCount(0);
    setSelectedSSIDs([]);
    setIsRecording(false);
    setRecordingData([]);
    setRecordingStartTime(null);
    setRecordingTime('00:00:00');
    setCurrentSessionId(null);
    setIsSSIDModalOpen(false);
  };

  const canStartRecording = selectedSSIDs.length > 0 && selectedSSIDs.length === deviceCount && isConnected;

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-primary text-white shadow-lg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-white bg-opacity-20 rounded-lg flex items-center justify-center">
                <Wifi className="h-6 w-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-semibold">3D Indoor Positioning System</h1>
                <p className="text-sm opacity-90">RSSI Signal Strength Monitor</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <span className="text-sm opacity-90">Real-time Network Analysis</span>
              <div className="flex items-center space-x-2">
                <div className={`w-3 h-3 rounded-full ${isConnected ? 'bg-green-400 animate-pulse' : 'bg-red-400'}`} />
                <span className="text-sm">{isConnected ? 'Connected' : 'Disconnected'}</span>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Left Panel - Configuration */}
          <div className="lg:col-span-1 space-y-6">
            <DeviceConfiguration
              deviceCount={deviceCount}
              selectedSSIDs={selectedSSIDs}
              onDeviceCountChange={handleDeviceCountChange}
              onConfigureSSIDs={handleConfigureSSIDs}
              disabled={isRecording}
            />

            <RecordingControls
              isRecording={isRecording}
              canStart={canStartRecording}
              recordingTime={recordingTime}
              recordCount={recordingData.length}
              onStart={handleStartRecording}
              onStop={handleStopRecording}
              onDownload={handleDownloadCSV}
              onRefresh={handleRefresh}
            />
          </div>

          {/* Right Panel - Data Visualization */}
          <div className="lg:col-span-2">
            <DataVisualization
              data={recordingData}
              selectedSSIDs={selectedSSIDs}
              isRecording={isRecording}
            />
          </div>
        </div>

        {/* Info Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-medium text-gray-500">Active Devices</h3>
                  <p className="text-2xl font-bold text-primary">{selectedSSIDs.length}</p>
                </div>
                <Smartphone className="h-8 w-8 text-primary opacity-50" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-medium text-gray-500">Data Points</h3>
                  <p className="text-2xl font-bold text-green-600">{recordingData.length}</p>
                </div>
                <Database className="h-8 w-8 text-green-600 opacity-50" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-medium text-gray-500">Recording Time</h3>
                  <p className="text-2xl font-bold text-orange-600 font-mono">{recordingTime}</p>
                </div>
                <Clock className="h-8 w-8 text-orange-600 opacity-50" />
              </div>
            </CardContent>
          </Card>
        </div>
      </main>

      {/* SSID Selection Modal */}
      <SSIDModal
        isOpen={isSSIDModalOpen}
        requiredCount={deviceCount}
        onClose={() => setIsSSIDModalOpen(false)}
        onConfirm={handleSSIDConfirm}
      />
    </div>
  );
}
