import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Play, Square, Download, RefreshCw, Clock, Database } from 'lucide-react';

interface RecordingControlsProps {
  isRecording: boolean;
  canStart: boolean;
  recordingTime: string;
  recordCount: number;
  onStart: () => void;
  onStop: () => void;
  onDownload: () => void;
  onRefresh: () => void;
  disabled?: boolean;
}

export function RecordingControls({
  isRecording,
  canStart,
  recordingTime,
  recordCount,
  onStart,
  onStop,
  onDownload,
  onRefresh,
  disabled = false
}: RecordingControlsProps) {
  const [lastUpdate, setLastUpdate] = useState<string>('--');

  useEffect(() => {
    if (isRecording) {
      const interval = setInterval(() => {
        setLastUpdate(new Date().toLocaleTimeString());
      }, 1000);
      return () => clearInterval(interval);
    }
  }, [isRecording]);

  const getStatusColor = () => {
    if (isRecording) return 'bg-red-500';
    if (canStart) return 'bg-green-500';
    return 'bg-gray-400';
  };

  const getStatusText = () => {
    if (isRecording) return 'Recording';
    if (canStart) return 'Ready';
    return 'Not Configured';
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <span>Recording Controls</span>
          <div className="flex items-center gap-2">
            <div className={`w-3 h-3 rounded-full ${getStatusColor()} ${isRecording ? 'animate-pulse' : ''}`} />
            <span className="text-sm text-gray-600">{getStatusText()}</span>
          </div>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex flex-wrap gap-3">
          <Button
            onClick={onStart}
            disabled={!canStart || isRecording || disabled}
            className="bg-green-600 hover:bg-green-700"
          >
            <Play className="h-4 w-4 mr-2" />
            Start Recording
          </Button>

          <Button
            onClick={onStop}
            disabled={!isRecording || disabled}
            variant="destructive"
          >
            <Square className="h-4 w-4 mr-2" />
            Stop Recording
          </Button>

          <Button
            onClick={onDownload}
            disabled={recordCount === 0 || disabled}
            className="bg-orange-600 hover:bg-orange-700"
          >
            <Download className="h-4 w-4 mr-2" />
            Download CSV
          </Button>

          <Button
            onClick={onRefresh}
            disabled={disabled}
            variant="outline"
          >
            <RefreshCw className="h-4 w-4 mr-2" />
            Refresh
          </Button>
        </div>

        {isRecording && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 p-4 bg-gray-50 rounded-lg">
            <div className="text-center">
              <div className="text-2xl font-bold text-blue-600">{recordingTime}</div>
              <div className="text-sm text-gray-600 flex items-center justify-center gap-1">
                <Clock className="h-3 w-3" />
                Recording Time
              </div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-green-600">{recordCount}</div>
              <div className="text-sm text-gray-600 flex items-center justify-center gap-1">
                <Database className="h-3 w-3" />
                Data Points
              </div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-gray-700">{lastUpdate}</div>
              <div className="text-sm text-gray-600">Last Update</div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
