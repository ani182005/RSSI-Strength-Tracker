import { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Wifi, Trash2 } from 'lucide-react';

interface SSIDModalProps {
  isOpen: boolean;
  requiredCount: number;
  onClose: () => void;
  onConfirm: (selectedSSIDs: string[]) => void;
}

export function SSIDModal({ isOpen, requiredCount, onClose, onConfirm }: SSIDModalProps) {
  const [ssidInputs, setSSIDInputs] = useState<string[]>([]);

  useEffect(() => {
    if (isOpen) {
      // Initialize array with empty strings for each device
      setSSIDInputs(Array(requiredCount).fill(''));
    }
  }, [isOpen, requiredCount]);

  const handleSSIDChange = (index: number, value: string) => {
    const newInputs = [...ssidInputs];
    newInputs[index] = value.trim();
    setSSIDInputs(newInputs);
  };

  const handleClearSSID = (index: number) => {
    const newInputs = [...ssidInputs];
    newInputs[index] = '';
    setSSIDInputs(newInputs);
  };

  const handleConfirm = () => {
    const validSSIDs = ssidInputs.filter(ssid => ssid.length > 0);
    if (validSSIDs.length === requiredCount) {
      onConfirm(validSSIDs);
      setSSIDInputs([]);
    }
  };

  const handleClose = () => {
    setSSIDInputs([]);
    onClose();
  };

  const validSSIDs = ssidInputs.filter(ssid => ssid.length > 0);
  const allFieldsFilled = validSSIDs.length === requiredCount;

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="max-w-md max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Wifi className="h-5 w-5" />
            Enter SSID Names
          </DialogTitle>
          <DialogDescription>
            Enter the WiFi network names (SSIDs) you want to monitor for RSSI signal strength.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          <div className="text-sm text-gray-600">
            Enter <span className="font-semibold text-blue-600">{requiredCount}</span> SSID name(s):
          </div>

          <div className="space-y-3 max-h-64 overflow-y-auto">
            {Array.from({ length: requiredCount }, (_, index) => (
              <div key={index} className="space-y-2">
                <Label htmlFor={`ssid-${index}`} className="text-sm font-medium">
                  Device {index + 1} SSID
                </Label>
                <div className="flex items-center space-x-2">
                  <Input
                    id={`ssid-${index}`}
                    type="text"
                    placeholder="Enter WiFi network name (e.g., MyWiFi_5G)"
                    value={ssidInputs[index] || ''}
                    onChange={(e) => handleSSIDChange(index, e.target.value)}
                    className="flex-1"
                  />
                  {ssidInputs[index] && (
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleClearSSID(index)}
                      className="h-10 w-10 p-0"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  )}
                </div>
              </div>
            ))}
          </div>

          <div className="text-xs text-gray-500">
            Filled: {validSSIDs.length} / {requiredCount}
          </div>

          {validSSIDs.length > 0 && (
            <div className="space-y-2">
              <Label className="text-sm font-medium text-gray-700">
                Entered SSIDs:
              </Label>
              <div className="space-y-1">
                {validSSIDs.map((ssid, index) => (
                  <div key={index} className="flex items-center gap-2 p-2 bg-blue-50 rounded text-sm">
                    <Wifi className="h-4 w-4 text-blue-600" />
                    <span className="text-gray-700">{ssid}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          <div className="flex justify-end space-x-3 pt-4 border-t">
            <Button variant="outline" onClick={handleClose}>
              Cancel
            </Button>
            <Button
              onClick={handleConfirm}
              disabled={!allFieldsFilled}
            >
              Confirm SSIDs ({validSSIDs.length}/{requiredCount})
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
