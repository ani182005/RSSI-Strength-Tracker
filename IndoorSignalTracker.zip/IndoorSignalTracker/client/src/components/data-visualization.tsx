import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ChartLine, Wifi } from 'lucide-react';
import { getRSSIColorClass } from '@/lib/csv-utils';
import { RssiDataPoint } from '@shared/schema';

interface DataVisualizationProps {
  data: RssiDataPoint[];
  selectedSSIDs: string[];
  isRecording: boolean;
}

export function DataVisualization({ data, selectedSSIDs, isRecording }: DataVisualizationProps) {
  if (selectedSSIDs.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <ChartLine className="h-5 w-5 text-primary" />
            Real-time RSSI Data
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-12 text-gray-500">
            <Wifi className="h-16 w-16 mx-auto mb-4 text-gray-300" />
            <h3 className="text-lg font-medium mb-2">No Data Available</h3>
            <p className="text-gray-400">Configure devices and start recording to view RSSI data</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <ChartLine className="h-5 w-5 text-primary" />
            Real-time RSSI Data
          </div>
          {isRecording && (
            <Badge variant="destructive" className="animate-pulse">
              Live Recording
            </Badge>
          )}
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="overflow-x-auto max-h-96 overflow-y-auto">
          <table className="w-full border-collapse border border-gray-200">
            <thead className="sticky top-0 bg-white">
              <tr className="bg-gray-50">
                <th className="border border-gray-200 px-4 py-3 text-left text-sm font-semibold text-gray-700">
                  Serial #
                </th>
                <th className="border border-gray-200 px-4 py-3 text-left text-sm font-semibold text-gray-700">
                  Timestamp
                </th>
                {selectedSSIDs.map((ssid) => (
                  <th
                    key={ssid}
                    className="border border-gray-200 px-4 py-3 text-left text-sm font-semibold text-gray-700"
                  >
                    {ssid} (dBm)
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {data.length === 0 ? (
                <tr>
                  <td
                    colSpan={selectedSSIDs.length + 2}
                    className="border border-gray-200 px-4 py-8 text-center text-gray-500"
                  >
                    {isRecording ? 'Waiting for data...' : 'No data recorded yet'}
                  </td>
                </tr>
              ) : (
                data.slice(-50).map((record) => (
                  <tr key={record.serialNumber} className="hover:bg-gray-50">
                    <td className="border border-gray-200 px-4 py-2 text-sm font-mono text-gray-700">
                      {record.serialNumber}
                    </td>
                    <td className="border border-gray-200 px-4 py-2 text-sm font-mono text-gray-700">
                      {new Date(record.timestamp).toLocaleTimeString()}
                    </td>
                    {selectedSSIDs.map((ssid) => {
                      const rssi = record.rssiValues[ssid];
                      const colorClass = rssi !== undefined ? getRSSIColorClass(rssi) : 'text-gray-400';
                      return (
                        <td
                          key={ssid}
                          className={`border border-gray-200 px-4 py-2 text-sm font-mono font-semibold ${colorClass}`}
                        >
                          {rssi !== undefined ? rssi : 'N/A'}
                        </td>
                      );
                    })}
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </CardContent>
    </Card>
  );
}
