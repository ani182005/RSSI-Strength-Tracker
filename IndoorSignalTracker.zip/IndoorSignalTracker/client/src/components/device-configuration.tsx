import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Settings, Wifi } from 'lucide-react';

interface DeviceConfigurationProps {
  deviceCount: number;
  selectedSSIDs: string[];
  onDeviceCountChange: (count: number) => void;
  onConfigureSSIDs: () => void;
  disabled?: boolean;
}

export function DeviceConfiguration({
  deviceCount,
  selectedSSIDs,
  onDeviceCountChange,
  onConfigureSSIDs,
  disabled = false
}: DeviceConfigurationProps) {
  const handleDeviceCountChange = (value: string) => {
    const count = parseInt(value);
    if (!isNaN(count)) {
      onDeviceCountChange(count);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Settings className="h-5 w-5 text-primary" />
          Device Configuration
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Number of Devices (Max: 10)
          </label>
          <Select value={deviceCount.toString()} onValueChange={handleDeviceCountChange} disabled={disabled}>
            <SelectTrigger>
              <SelectValue placeholder="Select number of devices" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="0">Select Device Count</SelectItem>
              {Array.from({ length: 10 }, (_, i) => i + 1).map((count) => (
                <SelectItem key={count} value={count.toString()}>
                  {count} Device{count > 1 ? 's' : ''}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {selectedSSIDs.length > 0 && (
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Selected SSIDs
            </label>
            <div className="space-y-2">
              {selectedSSIDs.map((ssid, index) => (
                <div key={index} className="flex items-center justify-between p-2 bg-gray-50 rounded-lg">
                  <div className="flex items-center gap-2">
                    <Wifi className="h-4 w-4 text-blue-600" />
                    <span className="text-sm text-gray-700">Device {index + 1}: {ssid}</span>
                  </div>
                  <Badge variant="secondary" className="text-xs">Ready</Badge>
                </div>
              ))}
            </div>
          </div>
        )}

        <Button 
          onClick={onConfigureSSIDs}
          disabled={deviceCount === 0 || disabled}
          className="w-full"
        >
          <Settings className="h-4 w-4 mr-2" />
          Enter SSID Names
        </Button>
      </CardContent>
    </Card>
  );
}
