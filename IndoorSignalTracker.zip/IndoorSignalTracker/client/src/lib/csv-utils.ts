import { RssiDataPoint } from '@shared/schema';

export interface CSVExportData {
  session: {
    sessionId: string;
    deviceCount: number;
    startTime: string;
    endTime?: string;
  };
  data: RssiDataPoint[];
}

export function generateCSVContent(exportData: CSVExportData): string {
  if (!exportData.data || exportData.data.length === 0) {
    return '';
  }

  // Get all unique SSIDs from the data
  const ssids = new Set<string>();
  exportData.data.forEach(record => {
    Object.keys(record.rssiValues).forEach(ssid => ssids.add(ssid));
  });

  const sortedSSIDs = Array.from(ssids).sort();

  // Create CSV header
  let csvContent = 'Serial Number,Timestamp';
  sortedSSIDs.forEach(ssid => {
    csvContent += `,${ssid} (dBm)`;
  });
  csvContent += '\n';

  // Add data rows
  exportData.data.forEach(record => {
    const timestamp = new Date(record.timestamp).toLocaleString();
    csvContent += `${record.serialNumber},${timestamp}`;
    
    sortedSSIDs.forEach(ssid => {
      const rssiValue = record.rssiValues[ssid];
      csvContent += `,${rssiValue !== undefined ? rssiValue : 'N/A'}`;
    });
    
    csvContent += '\n';
  });

  return csvContent;
}

export function downloadCSV(content: string, filename: string): void {
  const blob = new Blob([content], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  
  if (link.download !== undefined) {
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', filename);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  }
}

export function generateFilename(sessionId?: string): string {
  const timestamp = new Date().toISOString().slice(0, 19).replace(/:/g, '-');
  const prefix = sessionId ? `rssi_session_${sessionId}` : 'rssi_data';
  return `${prefix}_${timestamp}.csv`;
}

export function getRSSIColorClass(rssi: number): string {
  if (rssi >= -50) return 'text-green-600'; // Excellent signal
  if (rssi >= -60) return 'text-blue-600';  // Good signal
  if (rssi >= -70) return 'text-yellow-600'; // Fair signal
  return 'text-red-600'; // Poor signal
}

export function getRSSIQualityLabel(rssi: number): string {
  if (rssi >= -50) return 'Excellent';
  if (rssi >= -60) return 'Good';
  if (rssi >= -70) return 'Fair';
  return 'Poor';
}
